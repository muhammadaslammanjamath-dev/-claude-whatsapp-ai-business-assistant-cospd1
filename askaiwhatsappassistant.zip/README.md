# AskAI Business Assistant

A WhatsApp AI business assistant for UK small business owners, built on Next.js 14 (App Router). One WhatsApp number, instant Claude-powered replies, 3 free messages then a £9/month Stripe subscription — fully automated.

## How it works

1. A business owner messages the WhatsApp number with any business question.
2. `/api/whatsapp-webhook` receives the inbound message from Twilio, looks up (or creates) the user in Vercel KV, and replies instantly using Claude.
3. After 3 free messages, the user hits a paywall with a Stripe Payment Link. Once they subscribe and reply `PAID`, the bot verifies the subscription with the Stripe API and unlocks unlimited messages.
4. `/api/stripe-webhook` keeps subscription state in sync (activation on `checkout.session.completed` / `customer.subscription.*`, and a graceful "subscription ended" WhatsApp message on `customer.subscription.deleted`).

## Tech stack

- Next.js 14 App Router, deployed on Vercel
- Twilio WhatsApp Business API
- Anthropic Claude API (`claude-sonnet-4-6`)
- Stripe Payment Links + webhooks
- Vercel KV for user state

## Project layout

```
app/
  api/
    whatsapp-webhook/route.ts   # Twilio inbound message handler
    stripe-webhook/route.ts     # Stripe subscription events
  page.tsx                      # simple deployment status page
lib/
  claude.ts                     # Claude API call + system prompt usage
  twilio.ts                     # send + signature validation
  stripe.ts                     # Stripe client + phone lookup
  kv.ts                         # Vercel KV user storage
  messages.ts                   # all WhatsApp message templates + system prompt
  types.ts                      # User type
```

## Setup

Takes about 30 minutes, free to start.

### 1. Twilio (WhatsApp sandbox)

- Sign up at [twilio.com](https://www.twilio.com), go to **Messaging → Try WhatsApp**, follow the sandbox setup.
- Note your **Account SID** and **Auth Token**.

### 2. Anthropic API key

- Sign up at [console.anthropic.com](https://console.anthropic.com), create an API key.

### 3. Stripe

- Create a Stripe account.
- Go to **Payment Links → Create new link**.
  - Product: AskAI Business Assistant
  - Price: £9.00 GBP / month, recurring
  - Add a custom field: **Phone number** (key `phone_number`) — this lets the app match a payment back to a WhatsApp number.
- Copy the payment link URL.
- After deploying, create a webhook endpoint pointing at `https://your-vercel-url.vercel.app/api/stripe-webhook`, subscribed to `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, and `customer.subscription.deleted`. Copy the signing secret.

### 4. Vercel KV

- On [vercel.com](https://vercel.com), go to **Storage → Create KV Database**.
- Copy the 4 KV environment variables it gives you.

### 5. Environment variables

Copy `.env.example` to `.env.local` and fill in every value:

```
ANTHROPIC_API_KEY=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
STRIPE_PAYMENT_LINK=
KV_URL=
KV_REST_API_URL=
KV_REST_API_TOKEN=
KV_REST_API_READ_ONLY_TOKEN=
NEXT_PUBLIC_BASE_URL=https://your-vercel-url.vercel.app
```

`NEXT_PUBLIC_BASE_URL` must exactly match the URL Twilio is configured to POST to — it's used to validate the inbound Twilio request signature.

### 6. Install & run locally

```bash
npm install
npm run dev
```

### 7. Deploy

- Push to GitHub, import into Vercel, add all environment variables above, deploy.

### 8. Connect Twilio

- Copy your Vercel deployment URL.
- In Twilio → WhatsApp Sandbox settings, set the "when a message comes in" webhook to:
  `https://your-vercel-url.vercel.app/api/whatsapp-webhook` (method `POST`).

### 9. Test

- Message your Twilio WhatsApp sandbox number and ask a business question. You should get a reply within a few seconds.
- Send 3 messages to trigger the paywall, subscribe via the Stripe link, then reply `PAID` to unlock unlimited access.
- Reply `HELP` at any time for the help menu.

## Notes

- `STOP` is handled both by Twilio's built-in WhatsApp opt-out mechanism and, as a fallback, directly in the webhook handler (sets `optedOut: true` on the user record so no further messages are sent).
- The AI never gives formal legal or financial advice — the system prompt in `lib/messages.ts` enforces this and always signs off as "AskAI Business Assistant".
